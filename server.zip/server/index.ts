import { InboxMessage, RegisterClientMessage, WorkerAccount } from "jazz";
import { startWorker } from "jazz-nodejs";
import { syncSpotify } from "./syncing/spotify-demo";

const localAddress = "ws://127.0.0.1:4200"

console.log("Starting worker...")

const { worker, experimental: { inbox } } = await startWorker({
  syncServer: localAddress,
  accountID: process.env.JAZZ_WORKER_ACCOUNT,
  accountSecret: process.env.JAZZ_WORKER_SECRET,
  AccountSchema: WorkerAccount,
})

console.log("Created worker")

const runningAccounts = new Map<string, () => void>
const workerRoot = await new Promise(resolve => {
  const unsubscribe = worker.subscribe({ resolve: { root: {} }}, (v) => {
    unsubscribe()
    resolve(v.root)
  })
})
console.log("wa2")
// const workerAccount = await worker.ensureLoaded({ resolve: { root: { integrations: { $each: {} } } }})
// await workerAccount.root.integrations.subscribe(
//   { resolve: { $each: {} } },
//   (integrations) => {
//     console.log("Updated integrations", integrations)
//     const newAccounts = integrations.filter(i => !runningAccounts.has(i.id))
//     const deletedAccounts = runningAccounts.keys().filter(id => !integrations.some(i => id == i.id))
    
//     // start syncing any new accounts
//     newAccounts.forEach(newA => {
//       const unsubscribe = newA.subscribe(
//         { resolve: { 
//           spotifyIntegration: {}
//         }},
//         (newA) => {
//           console.log("Syncing Spotify for account", newA.id)
//           syncSpotify(newA.spotifyIntegration)
//         }
//       )
//       runningAccounts.set(newA.id, unsubscribe)
//     })

//     // and stop syncing any that no longer exist
//     deletedAccounts.forEach(id => {
//       runningAccounts.get(id)?.()
//       runningAccounts.delete(id)
//     })
//   },
// )

// inbox.subscribe(
//   InboxMessage,
//   async (message, senderID) => {
//     // const userAccount = await FountainAccount.load(senderID, worker, {})
//     // if (!userAccount) {
//     //   console.error(`Received message from unknown account: ${senderID}`)
//     //   return
//     // }
//     switch (message.type) {
//       case "register":
//         const registerMessage: RegisterClientMessage = message.castAs(RegisterClientMessage);
//         (worker as unknown as WorkerAccount).root?.integrations?.push(registerMessage.integrations)
//         break
//       default:
//         console.error(`Unknown inbox message type: ${message.type}`)
//     }
//   }
// )


console.log("Worker started")