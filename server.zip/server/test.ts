import { startWorker } from "jazz-nodejs";
import { Account, co, CoMap, CoList, Group } from "jazz-tools";
import { FountainIntegrations, WorkerAccount2 } from "jazz";


export class WorkerAccount extends Account {}

const localAddress = "ws://127.0.0.1:4200"

const { worker, experimental: { inbox } } = await startWorker({
  syncServer: localAddress,
  accountID: process.env.JAZZ_WORKER_ACCOUNT,
  accountSecret: process.env.JAZZ_WORKER_SECRET,
  AccountSchema: WorkerAccount,
})

await worker.ensureLoaded({ resolve: { root: {} }})
console.log("Worker started")