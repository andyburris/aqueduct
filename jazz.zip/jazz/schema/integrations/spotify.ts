import { AccessToken } from "@spotify/web-api-ts-sdk";
import { FullSpotifyPlaylist } from "aqueduct";
import { co, CoList } from "jazz-tools";
import { cojson } from "../../test";
import { Integration } from "../integrations";

export class SpotifyIntegration extends Integration {
    authentication = co.optional.json<AccessToken>();
    playlists = co.optional.ref(CoList.Of(cojson.json<FullSpotifyPlaylist>()))
}